Directory structure
===================
examples for Win32 (D2010) and Win64 (XE2+):
VCL\ 
  Example 1 - Basic usage\
  Example 2 - Fluent interfaces 1\
  Example 3 - Fluent interfaces 2\
  Example 4 - Loading 1\
  Example 5 - Comments 1\
  Example 6 - Comments 2\
  Example 7 - Processing Instructions 1\
  Example 8 - Processing Instructions 2\
  Example 9 - Extending VerySimpleXml 1\

examples for Win32/64, MacOS X (XE2+):
FMX-Desktop\   

examples for iOS/Android (XE5+):
FMX-Mobile\    

XML Testsuite:
XMLTestSuite\ 